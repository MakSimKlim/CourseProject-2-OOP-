﻿/*
  Программы к учебнику информатики для 11 класса углублённого уровня.
  Визуальное программирование на C#.
  Авторы: К.Ю. Поляков, Е.А. Еремин
  E-mail: kpolyakov@mail.ru
  Сайт поддержки: http://kpolyakov.spb.ru

  Глава 7. Объектно-ориентированное программирование
  Проект № 5. Компоненты для ввода данных
  
*/
namespace InputComponents
{
    partial class MainForm
    {
        /// <summary>
        /// Требуется переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Обязательный метод для поддержки конструктора - не изменяйте
        /// содержимое данного метода при помощи редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.rEdit = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.gEdit = new System.Windows.Forms.TextBox();
            this.bEdit = new System.Windows.Forms.TextBox();
            this.rgbLabel = new System.Windows.Forms.Label();
            this.rgbPanel = new System.Windows.Forms.Panel();
            this.SuspendLayout();
            // 
            // rEdit
            // 
            this.rEdit.Location = new System.Drawing.Point(39, 11);
            this.rEdit.Margin = new System.Windows.Forms.Padding(4);
            this.rEdit.Name = "rEdit";
            this.rEdit.Size = new System.Drawing.Size(54, 23);
            this.rEdit.TabIndex = 0;
            this.rEdit.Text = "123";
            this.rEdit.TextChanged += new System.EventHandler(this.rEdit_TextChanged);
            this.rEdit.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.rEdit_KeyPress);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 14);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(30, 17);
            this.label1.TabIndex = 1;
            this.label1.Text = "R =";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(9, 40);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(31, 17);
            this.label2.TabIndex = 2;
            this.label2.Text = "G =";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(11, 67);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(29, 17);
            this.label3.TabIndex = 3;
            this.label3.Text = "B =";
            // 
            // gEdit
            // 
            this.gEdit.Location = new System.Drawing.Point(39, 37);
            this.gEdit.Margin = new System.Windows.Forms.Padding(4);
            this.gEdit.Name = "gEdit";
            this.gEdit.Size = new System.Drawing.Size(54, 23);
            this.gEdit.TabIndex = 4;
            this.gEdit.Text = "56";
            this.gEdit.TextChanged += new System.EventHandler(this.rEdit_TextChanged);
            this.gEdit.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.rEdit_KeyPress);
            // 
            // bEdit
            // 
            this.bEdit.Location = new System.Drawing.Point(39, 64);
            this.bEdit.Margin = new System.Windows.Forms.Padding(4);
            this.bEdit.Name = "bEdit";
            this.bEdit.Size = new System.Drawing.Size(54, 23);
            this.bEdit.TabIndex = 5;
            this.bEdit.Text = "80";
            this.bEdit.TextChanged += new System.EventHandler(this.rEdit_TextChanged);
            this.bEdit.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.rEdit_KeyPress);
            // 
            // rgbLabel
            // 
            this.rgbLabel.AutoSize = true;
            this.rgbLabel.Font = new System.Drawing.Font("Courier New", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.rgbLabel.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.rgbLabel.Location = new System.Drawing.Point(109, 10);
            this.rgbLabel.Name = "rgbLabel";
            this.rgbLabel.Size = new System.Drawing.Size(101, 23);
            this.rgbLabel.TabIndex = 6;
            this.rgbLabel.Text = "#7B3850";
            // 
            // rgbPanel
            // 
            this.rgbPanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.rgbPanel.Location = new System.Drawing.Point(113, 36);
            this.rgbPanel.Name = "rgbPanel";
            this.rgbPanel.Size = new System.Drawing.Size(93, 51);
            this.rgbPanel.TabIndex = 7;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(216, 98);
            this.Controls.Add(this.rgbPanel);
            this.Controls.Add(this.rgbLabel);
            this.Controls.Add(this.bEdit);
            this.Controls.Add(this.gEdit);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.rEdit);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "MainForm";
            this.Text = "RGB-кодирование";
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox rEdit;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox gEdit;
        private System.Windows.Forms.TextBox bEdit;
        private System.Windows.Forms.Label rgbLabel;
        private System.Windows.Forms.Panel rgbPanel;
    }
}

