﻿/*
  Программы к учебнику информатики для 11 класса углублённого уровня.
  Версия для C#.
  Авторы: К.Ю. Поляков, Е.А. Еремин
  E-mail: kpolyakov@mail.ru
  Сайт поддержки: http://kpolyakov.spb.ru

  Глава 7. Объектно-ориентированное программирование
  Проект № 1a. Попугай

  PARROT_A.CS - начальный вариант

*/
using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApplication1
{
    /*---------------------------------------------
      Класс TParrot - модель попугая
    ---------------------------------------------*/
    class TParrot
    {
        public string text;
        public TParrot() { 
            text = "Привет, друзья!";
        }
        public void say()
        {
            Console.WriteLine( text );
        }
    };
    /*--------------------------------------------
      Основная программа
    ---------------------------------------------*/
    class Program
    {
        static void Main(string[] args)
        {
            TParrot p = new TParrot();
            p.say();
            Console.ReadKey();
        }
    }
}
