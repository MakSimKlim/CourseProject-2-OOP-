﻿/*
  Программы к учебнику информатики для 11 класса углублённого уровня.
  Версия для C#.
  Авторы: К.Ю. Поляков, Е.А. Еремин
  E-mail: kpolyakov@mail.ru
  Сайт поддержки: http://kpolyakov.spb.ru

  Глава 7. Объектно-ориентированное программирование
  Проект № 1a. Попугай

  PARROT_E.CS - модификация 4
     + попугая можно учить новым словам

*/
using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApplication1
{
    /*---------------------------------------------
      Класс TParrot - модель попугая
    ---------------------------------------------*/
    class TParrot
    {
        public List<string> text;
        public TParrot( string text0 ) { 
            text = new List<string>();
            text.Add( text0 );
        }
        public void say( int count )
        {   
            Random rand = new Random();
            int choice = rand.Next(text.Count);
            for( int i = 0; i < count; i++ )
                Console.Write(text[choice] + " ");
            Console.WriteLine();
        }
        public void learn(string text0)
        {
            text.Add( text0 );
        }
    };
    /*--------------------------------------------
      Основная программа
    ---------------------------------------------*/
    class Program
    {
        static void Main(string[] args)
        {
            TParrot p = new TParrot( "Гав!" );
            p.say( 1 );
            p.learn("Мяу!");
            p.say( 3 );
            Console.ReadKey();
        }
    }
}
