﻿/*
  Программы к учебнику информатики для 11 класса углублённого уровня.
  Версия для C#.
  Авторы: К.Ю. Поляков, Е.А. Еремин
  E-mail: kpolyakov@mail.ru
  Сайт поддержки: http://kpolyakov.spb.ru

  Глава 7. Объектно-ориентированное программирование
  Проект № 1a. Попугай

  PARROT_D.CS - модификация 3
     + при вызове метода say можно задать количество повторений

*/
using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApplication1
{
    /*---------------------------------------------
      Класс TParrot - модель попугая
    ---------------------------------------------*/
    class TParrot
    {
        public string text;
        public TParrot( string text0 ) { 
            text = text0;
        }
        public void say( int count )
        {
            for( int i = 0; i < count; i++ )
                Console.Write(text + " ");
            Console.WriteLine();
        }
        public void newText(string text0)
        {
            text = text0;
        }
    };
    /*--------------------------------------------
      Основная программа
    ---------------------------------------------*/
    class Program
    {
        static void Main(string[] args)
        {
            TParrot p = new TParrot( "Гав!" );
            p.say( 1 );
            p.newText("Мяу!");
            p.say( 3 );
            Console.ReadKey();
        }
    }
}
