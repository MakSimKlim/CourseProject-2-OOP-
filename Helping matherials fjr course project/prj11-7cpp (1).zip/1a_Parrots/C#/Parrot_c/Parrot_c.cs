﻿/*
  Программы к учебнику информатики для 11 класса углублённого уровня.
  Версия для C#.
  Авторы: К.Ю. Поляков, Е.А. Еремин
  E-mail: kpolyakov@mail.ru
  Сайт поддержки: http://kpolyakov.spb.ru

  Глава 7. Объектно-ориентированное программирование
  Проект № 1a. Попугай

  PARROT_C.CS - модификация 2
     + можно сменить фразу, которую говорит попугай 

*/
using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApplication1
{
    /*---------------------------------------------
      Класс TParrot - модель попугая
    ---------------------------------------------*/
    class TParrot
    {
        public string text;
        public TParrot( string text0 ) { 
            text = text0;
        }
        public void say()
        {
            Console.WriteLine( text );
        }
        public void newText( string text0 )
        {
            text = text0;
        }
    };
    /*--------------------------------------------
      Основная программа
    ---------------------------------------------*/
    class Program
    {
        static void Main(string[] args)
        {
            TParrot p = new TParrot( "Гав!" );
            p.say();
            p.newText("Мяу!");
            p.say();
            Console.ReadKey();
        }
    }
}
