﻿/*
  Программы к учебнику информатики для 11 класса углублённого уровня.
  Версия для C#.
  Авторы: К.Ю. Поляков, Е.А. Еремин
  E-mail: kpolyakov@mail.ru
  Сайт поддержки: http://kpolyakov.spb.ru

  Глава 7. Объектно-ориентированное программирование
  Проект № 1a. Попугай

  PARROT_B.CS - модификация 1
     + при создании попугая можно задать фразу 

*/
using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApplication1
{
    /*---------------------------------------------
      Класс TParrot - модель попугая
    ---------------------------------------------*/
    class TParrot
    {
        public string text;
        public TParrot( string text0 ) { 
            text = text0;
        }
        public void say()
        {
            Console.WriteLine( text );
        }
    };
    /*--------------------------------------------
      Основная программа
    ---------------------------------------------*/
    class Program
    {
        static void Main(string[] args)
        {
            TParrot p1 = new TParrot( "Гав!" );
            TParrot p2 = new TParrot( "Мяу!" );
            p1.say();
            p2.say();
            Console.ReadKey();
        }
    }
}
