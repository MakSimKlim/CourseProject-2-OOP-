﻿/*
  Программы к учебнику информатики для 11 класса углублённого уровня.
  Визуальное программирование на C#.
  Авторы: К.Ю. Поляков, Е.А. Еремин
  E-mail: kpolyakov@mail.ru
  Сайт поддержки: http://kpolyakov.spb.ru

  Глава 7. Объектно-ориентированное программирование
  Проект № 7. Модель и представление. Вычисление арифметических выражений
  
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace Calculator
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        public void Log(string s)
        {
            using (StreamWriter sw = File.AppendText("results.txt") )
            {
                sw.WriteLine(s);
            }
        }

        private void Input_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                try
                {
                    double x = Calculator.Calc(Input.Text);
                    Answers.Text += Input.Text + "=" + x.ToString() + "\r\n";
                    int i = Input.FindString(Input.Text);
                    if (i < 0)
                    {
                        Input.Items.Insert(0, Input.Text);
                        Log(Input.Text + "=" + x.ToString());
                    }
                }
                catch
                {
                    MessageBox.Show("Неверное выражение:\n" + Input.Text, 
                                    "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    Log("Неверное выражение " + Input.Text);
                }
            }
        }
    }
}
