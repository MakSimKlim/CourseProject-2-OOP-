﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Calculator
{
    static class Calculator
    {
        static int Priority(char op)
        {
            switch (op)
            {
                case '+':
                case '-': return 1;
                case '*':
                case '/': return 2;
            }
            return 100;
        }

        static int LastOp(string s)
        {
        int i, minPrt, res, nest;
        minPrt = 50;
        res = -1;
        nest = 0;
        for (i = 0; i < s.Length; i++)
        {
            int prt = Priority(s[i]);
            if (s[i] == '(') nest++;
            else if (s[i] == ')') nest--;
            else if (nest == 0  &&  prt <= minPrt)
              {
                minPrt = prt;
                res = i;
              }
        }
        return res;
        }

        public static double Calc(string s)
        {
            int k;
            double n1, n2, res = 0;
            k = LastOp ( s );
            if (k < 0)
            {
                if (s[0] == '(')
                    return Calc(s.Substring(1, s.Length - 2));
                else if (s.StartsWith("abs"))
                    return Math.Abs(Calc(s.Substring(4, s.Length - 5)));
                else if (s.StartsWith("sin"))
                    return Math.Sin(Calc(s.Substring(4, s.Length - 5)));
                else if (s.StartsWith("cos"))
                    return Math.Cos(Calc(s.Substring(4, s.Length - 5)));
                else if (s.StartsWith("sqrt"))
                    return Math.Sqrt(Calc(s.Substring(5, s.Length - 6)));
                else
                    return Double.Parse(s);
            }
            n1 = Calc( s.Substring(0, k) ); // левая часть
            n2 = Calc( s.Substring(k+1) );  // правая часть 
            switch ( s[k] ) {
                case '+': res = n1 + n2; break;
                case '-': res = n1 - n2; break;
                case '*': res = n1 * n2; break;
                case '/': res = n1 / n2; break;
            }
            return res;
        }
    
    }
}
