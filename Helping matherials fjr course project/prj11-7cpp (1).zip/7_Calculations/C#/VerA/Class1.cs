﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Calculator
{
    static class Calculator
    {
        static int Priority(char op)
        {
            switch (op)
            {
                case '+':
                case '-': return 1;
                case '*':
                case '/': return 2;
            }
            return 100;
        }

        static int LastOp(string s)
        {
        int i, minPrt, res;
        minPrt = 50;
        res = -1;
        for (i = 0; i < s.Length; i++)
        {
            int prt = Priority(s[i]);
            if (prt <= minPrt)
            {
                minPrt = prt;
                res = i;
            }
        }
        return res;
        }

        public static double Calc(string s)
        {
            int k;
            double n1, n2, res = 0;
            k = LastOp ( s );
            if ( k < 0 ) return Double.Parse(s);
            n1 = Calc( s.Substring(0, k) ); // левая часть
            n2 = Calc( s.Substring(k+1) );  // правая часть 
            switch ( s[k] ) {
                case '+': res = n1 + n2; break;
                case '-': res = n1 - n2; break;
                case '*': res = n1 * n2; break;
                case '/': res = n1 / n2; break;
            }
            return res;
        }
    
    }
}
