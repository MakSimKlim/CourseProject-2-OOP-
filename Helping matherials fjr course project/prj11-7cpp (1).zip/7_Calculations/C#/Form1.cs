﻿/*
  Программы к учебнику информатики для 11 класса углублённого уровня.
  Визуальное программирование на C#.
  Авторы: К.Ю. Поляков, Е.А. Еремин
  E-mail: kpolyakov@mail.ru
  Сайт поддержки: http://kpolyakov.spb.ru

  Глава 7. Объектно-ориентированное программирование
  Проект № 7. Модель и представление. Вычисление арифметических выражений
  
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Calculator
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void Input_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                int x = Calculator.Calc(Input.Text);
                Answers.Text += Input.Text + "=" + x.ToString() + "\r\n";
                int i = Input.FindString(Input.Text);
                if (i < 0)
                    Input.Items.Insert(0, Input.Text);
            }
        }
    }
}
