﻿/*
  Программы к учебнику информатики для 11 класса углублённого уровня.
  Визуальное программирование на C#.
  Авторы: К.Ю. Поляков, Е.А. Еремин
  E-mail: kpolyakov@mail.ru
  Сайт поддержки: http://kpolyakov.spb.ru

  Глава 7. Объектно-ориентированное программирование
  Проект № 6. Усовершенствование компонента TextBox
  
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void decEdit_TextChanged(object sender, EventArgs e)
        {
            hexLabel.Text = decEdit.Value.ToString("X");
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            decEdit_TextChanged(sender, e);
        }
    }
}
