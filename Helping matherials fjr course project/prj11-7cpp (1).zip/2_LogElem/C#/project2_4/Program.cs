﻿/*
  Программы к учебнику информатики для 11 класса углублённого уровня.
  Версия для C#.
  Авторы: К.Ю. Поляков, Е.А. Еремин
  E-mail: kpolyakov@mail.ru
  Сайт поддержки: http://kpolyakov.spb.ru

  Глава 7. Объектно-ориентированное программирование
  Проект № 2. Логические элементы (иерархия)

  project2_4 - модификация 4     
     + собран триггер на элементах TAndOr

*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class Program
    {
        /*---------------------------------------------
           Класс TNAndTrigger - триггер на двух Not-And
        ---------------------------------------------*/
        class TNAndTrigger : Log_elem.TLog2In
        {
            private bool FRes1;
            private Log_elem.TNotAnd FNOr1, FNOr2;
            public TNAndTrigger()
            {
                FNOr1 = new Log_elem.TNotAnd();
                FNOr2 = new Log_elem.TNotAnd();
            }
            protected override void calc()
            {
                FNOr1.In1 = In1;
                FNOr2.In2 = In2;
                FNOr1.In2 = FNOr2.Res;
                FNOr2.In1 = FNOr1.Res;
                FRes = FNOr2.Res;
                FRes1 = FNOr1.Res;
            }
            public bool Res1
            {
                get { return FRes1; }
            }
        };
        /*---------------------------------------------
            Основная программа
        ---------------------------------------------*/
        static void Main(string[] args)
        {
            TNAndTrigger trigNAnd = new TNAndTrigger();
            int S, R;

            Console.WriteLine("  S   R  | Q   !Q ");
            Console.WriteLine("--------------------");

            for (S = 0; S <= 1; S++)
            {
                trigNAnd.In1 = (S > 0);
                for (R = 0; R <= 1; R++)
                {
                    trigNAnd.In2 = (R > 0);
                    Console.WriteLine("  {0}   {1}  | {2}   {3}", S, R,
                                       Convert.ToInt32(trigNAnd.Res),
                                       Convert.ToInt32(trigNAnd.Res1));
                }
            }

            // режим хранения бита при одном состоянии 

            trigNAnd.In1 = false;
            trigNAnd.In2 = true;
            S = 1;
            R = 1;
            trigNAnd.In1 = (S > 0);
            trigNAnd.In2 = (R > 0);
            Console.WriteLine("  {0}   {1}  | {2}   {3}", S, R,
                               Convert.ToInt32(trigNAnd.Res),
                               Convert.ToInt32(trigNAnd.Res1));

            while (!Console.KeyAvailable) ;
        }
    }
}
