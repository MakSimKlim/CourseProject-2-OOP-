﻿/*
  Программы к учебнику информатики для 11 класса углублённого уровня.
  Версия для C#.
  Авторы: К.Ю. Поляков, Е.А. Еремин
  E-mail: kpolyakov@mail.ru
  Сайт поддержки: http://kpolyakov.spb.ru

  Глава 7. Объектно-ориентированное программирование
  Проект № 2. Логические элементы (иерархия)

  project_2 - начальный вариант

*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class Program
    {
        /*---------------------------------------------
          Класс TLogElement - логический элемент
        ---------------------------------------------*/
        abstract class TLogElement
        {
            private bool FIn1;
            protected bool FRes;
            protected abstract void calc();
            public bool In1
            {
                get { return FIn1; }
                set
                {
                    FIn1 = value;
                    calc();
                }
            }
            public bool Res
            {
                get { return FRes; }
            }
        };

        /*---------------------------------------------
          Классы TNot, TAnd, TOr - базовый набор
        ---------------------------------------------*/
        class TNot : TLogElement
        {
            protected override void calc()
            {
                FRes = !In1;
            }
        };
        abstract class TLog2In : TLogElement
        {
            bool FIn2;
            public bool In2 
            {
                get { return FIn2; }
                set
                {
                    FIn2 = value;
                    calc();
                }
            }
        };
        class TAnd : TLog2In
        {
            protected override void calc()
            {
                FRes = In1 && In2;
            }
        };
        class TOr : TLog2In
        {
            protected override void calc()
            {
                FRes = In1 || In2;
            }
        };
        /*---------------------------------------------
          Основная программа
        ---------------------------------------------*/
        static void Main(string[] args)
        {
            TNot elNot = new TNot();
            TAnd elAnd = new TAnd();
            int A, B;

            Console.WriteLine(" A  B  !(A&B)");
            Console.WriteLine("----------------");
            for (A = 0; A <= 1; A++)
            {
                elAnd.In1 = (A > 0);
                for (B = 0; B <= 1; B++)
                {
                    elAnd.In2 = (B > 0) ;
                    elNot.In1 = elAnd.Res;
                    Console.WriteLine(" {0}  {1}    {2}", A, B,  Convert.ToInt32(elNot.Res) );
                }
            }

            while ( ! Console.KeyAvailable );
        }
    }
}
