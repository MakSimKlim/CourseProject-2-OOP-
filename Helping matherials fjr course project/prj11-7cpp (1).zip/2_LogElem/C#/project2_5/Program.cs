﻿/*
  Программы к учебнику информатики для 11 класса углублённого уровня.
  Версия для C#.
  Авторы: К.Ю. Поляков, Е.А. Еремин
  E-mail: kpolyakov@mail.ru
  Сайт поддержки: http://kpolyakov.spb.ru

  Глава 7. Объектно-ориентированное программирование
  Проект № 2. Логические элементы (иерархия)

  project2_5 - модификация 5     
     + собран шифратор "4 в 2"

*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class Program
    {
        /*---------------------------------------------
          Класс TCoder - шифратор "4 в 2" на двух Or
        ---------------------------------------------*/
        class TCoder
        {
            private Log_elem.TOr FOr0, FOr1;
            public TCoder()
            {
                FOr0 = new Log_elem.TOr();
                FOr1 = new Log_elem.TOr();
            }
            public void Inputs(bool In0, bool In1, bool In2, bool In3)
            {
                FOr0.In1 = In1;
                FOr0.In2 = In3;
                FOr1.In1 = In2;
                FOr1.In2 = In3;
            }
            public bool Out0
            {
                get { return FOr0.Res; }
            }
            public bool Out1
            {
                get { return FOr1.Res; }
            }
        };
        /*---------------------------------------------
            Основная программа
        ---------------------------------------------*/
        static void Main(string[] args)
        {
            TCoder coder = new TCoder();
            bool X0, X1, X2, X3;
            int i;

            Console.WriteLine("  X3  X2  X1  X0 | C1  C0'");
            Console.WriteLine("--------------------------");

            for (i = 0; i <= 3; i++)
            {
                X0 = (i == 0);
                X1 = (i == 1);
                X2 = (i == 2);
                X3 = (i == 3);
                coder.Inputs(X0, X1, X2, X3);
                Console.WriteLine("   {0}   {1}  {2}   {3}  | {4}   {5}", 
                         Convert.ToInt32(X3), 
                         Convert.ToInt32(X2), 
                         Convert.ToInt32(X1), 
                         Convert.ToInt32(X0), 
                         Convert.ToInt32(coder.Out1), 
                         Convert.ToInt32(coder.Out0) );
            }
            while (!Console.KeyAvailable) ;
        }
    }
}
