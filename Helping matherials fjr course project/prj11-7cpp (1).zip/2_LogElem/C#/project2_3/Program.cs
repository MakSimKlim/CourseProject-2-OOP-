﻿/*
  Программы к учебнику информатики для 11 класса углублённого уровня.
  Версия для C#.
  Авторы: К.Ю. Поляков, Е.А. Еремин
  E-mail: kpolyakov@mail.ru
  Сайт поддержки: http://kpolyakov.spb.ru

  Глава 7. Объектно-ориентированное программирование
  Проект № 2. Логические элементы (иерархия)

  project2_3 - модификация 3     
     + собран триггер на элементах TNotOr

*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class Program
    {
        /*---------------------------------------------
           Класс TNOrTrigger - триггер на двух Not-Or
        ---------------------------------------------*/
        class TNOrTrigger : Log_elem.TLog2In
        {
            private bool FRes1;
            private Log_elem.TNotOr FNOr1, FNOr2;
            public TNOrTrigger()
            {
                FNOr1 = new Log_elem.TNotOr();
                FNOr2 = new Log_elem.TNotOr();
            }
            protected override void calc()
            {
                FNOr1.In1 = In1;
                FNOr2.In2 = In2;
                FNOr1.In2 = FNOr2.Res;
                FNOr2.In1 = FNOr1.Res;
                FRes = FNOr2.Res;
                FRes1 = FNOr1.Res;
            }
            public bool Res1
            {
                get { return FRes1; }
            }
        };
        /*---------------------------------------------
            Основная программа
        ---------------------------------------------*/
        static void Main(string[] args)
        {
            TNOrTrigger trigNOr = new TNOrTrigger();
            int S, R;

            Console.WriteLine("  S   R  | Q   !Q ");
            Console.WriteLine("--------------------");

            // режим хранения бита при одном состоянии 

            trigNOr.In1 = true;
            trigNOr.In2 = false;
            S = 0;
            R = 0;
            trigNOr.In1 = (S > 0);
            trigNOr.In2 = (R > 0);
            Console.WriteLine("  {0}   {1}  | {2}   {3}", S, R, 
                               Convert.ToInt32(trigNOr.Res), 
                               Convert.ToInt32(trigNOr.Res1) );

            // режим хранения бита при другом состоянии 

            trigNOr.In1 = false;
            trigNOr.In2 = true;

            for (S = 0; S <= 1; S++)
            {
                trigNOr.In1 = (S > 0);
                for (R = 0; R <= 1; R++)
                {
                    trigNOr.In2 = (R > 0);
                    Console.WriteLine("  {0}   {1}  | {2}   {3}", S, R,
                                       Convert.ToInt32(trigNOr.Res),
                                       Convert.ToInt32(trigNOr.Res1));
                }
            }
            while (!Console.KeyAvailable) ;
        }
    }
}
