﻿/*
  Программы к учебнику информатики для 11 класса углублённого уровня.
  Версия для C#.
  Авторы: К.Ю. Поляков, Е.А. Еремин
  E-mail: kpolyakov@mail.ru
  Сайт поддержки: http://kpolyakov.spb.ru

  Глава 7. Объектно-ориентированное программирование
  Проект № 2. Логические элементы (иерархия)

  project2_6 - модификация 6     
     + собран дешифратор "2 в 4"

*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class Program
    {
        /*---------------------------------------------
          Класс TDecoder - дешифратор "2 в 4"
        ---------------------------------------------*/
        public class TDecoder : Log_elem.TLog2In
        {
            protected override void calc()
            {
                FRes = !In1 && !In2;
            }
            public int Output(int no)
            {
                bool res = Res;
                switch (no)
                {
                    case 1: res = (!In2) && In1; break;
                    case 2: res = In2 && (!In1); break;
                    case 3: res = In2 && In1; break;
                }
                return Convert.ToInt32(res);
            }
        };
        /*---------------------------------------------
            Основная программа
        ---------------------------------------------*/
        static void Main(string[] args)
        {

            TDecoder decoder = new TDecoder();
            int C0, C1;

            Console.WriteLine("  C1  C0 | X3  X2  X1  X0");
            Console.WriteLine("--------------------------");

            for (C1 = 0; C1 <= 1; C1++)
                for (C0 = 0; C0 <= 1; C0++)
                {
                    decoder.In1 = (C0 > 0);
                    decoder.In2 = (C1 > 0);
                    Console.WriteLine("  {0}   {1}  |  {2}   {3}   {4}   {5}",
                         C1, C0, decoder.Output(3), decoder.Output(2),
                         decoder.Output(1), decoder.Output(0) );
                }
            
            while (!Console.KeyAvailable) ;
        }
    }
}
