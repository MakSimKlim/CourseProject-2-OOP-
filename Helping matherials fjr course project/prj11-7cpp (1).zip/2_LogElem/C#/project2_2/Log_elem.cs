﻿/*
  Программы к учебнику информатики для 11 класса углублённого уровня.
  Версия для C#.
  Авторы: К.Ю. Поляков, Е.А. Еремин
  E-mail: kpolyakov@mail.ru
  Сайт поддержки: http://kpolyakov.spb.ru

  Глава 7. Объектно-ориентированное программирование
  Проект № 2. Логические элементы (иерархия)

  project2_2 - модификация 2     
     + добавлены классы TXor, TNotAnd, TNotOr
     + классы выделены в модуль Log_elem.cs

*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    public class Log_elem
    {
        /*---------------------------------------------
          Класс TLogElement - логический элемент
        ---------------------------------------------*/
        public abstract class TLogElement
        {
            private bool FIn1;
            protected bool FRes;
            protected abstract void calc();
            public bool In1
            {
                get { return FIn1; }
                set
                {
                    FIn1 = value;
                    calc();
                }
            }
            public bool Res
            {
                get { return FRes; }
            }
        };

        /*---------------------------------------------
          Классы TNot, TAnd, TOr - базовый набор
        ---------------------------------------------*/
        public class TNot : TLogElement
        {
            protected override void calc()
            {
                FRes = !In1;
            }
        };
        public abstract class TLog2In : TLogElement
        {
            bool FIn2;
            public bool In2
            {
                get { return FIn2; }
                set
                {
                    FIn2 = value;
                    calc();
                }
            }
        };
        public class TAnd : TLog2In
        {
            protected override void calc()
            {
                FRes = In1 && In2;
            }
        };
        public class TOr : TLog2In
        {
            protected override void calc()
            {
                FRes = In1 || In2;
            }
        };
        /*---------------------------------------------
          Классы TXor, TNotAnd, TNotOr
        ---------------------------------------------*/
        public class TXor : TLog2In
        {
            protected override void calc()
            {
                FRes = In1 != In2;
            }
        };
        public class TNotAnd : TLog2In
        {
            protected override void calc()
            {
                FRes = !(In1 && In2);
            }
        };
        public class TNotOr : TLog2In
        {
            protected override void calc()
            {
                FRes = ! (In1 || In2);
            }
        };
    }
}
