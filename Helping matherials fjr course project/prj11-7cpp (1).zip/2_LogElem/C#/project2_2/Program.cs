﻿/*
  Программы к учебнику информатики для 11 класса углублённого уровня.
  Версия для C#.
  Авторы: К.Ю. Поляков, Е.А. Еремин
  E-mail: kpolyakov@mail.ru
  Сайт поддержки: http://kpolyakov.spb.ru

  Глава 7. Объектно-ориентированное программирование
  Проект № 2. Логические элементы (иерархия)

  project2_2 - модификация 2     
     + добавлены классы TXor, TNotAnd, TNotOr
     + классы выделены в модуль Log_elem.cs

*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class Program
    {
        /*---------------------------------------------
          Тестирование логического элемента с двумя входами
        ---------------------------------------------*/
        static void TestElement(Log_elem.TLog2In L, string info)
        {
            int A, B;
            Console.WriteLine();
            Console.WriteLine(" A  B  {0}", info);
            Console.WriteLine("----------------");
            for (A = 0; A <= 1; A++)
            {
                L.In1 = (A > 0);
                for (B = 0; B <= 1; B++)
                {
                    L.In2 = (B > 0);
                    Console.WriteLine(" {0}  {1}    {2}", A, B, Convert.ToInt32(L.Res));
                }
            }
        }
        /*---------------------------------------------
          Основная программа
        ---------------------------------------------*/
        static void Main(string[] args)
        {
            Log_elem.TXor elXor = new Log_elem.TXor();
            Log_elem.TNotAnd elNotAnd = new Log_elem.TNotAnd();
            Log_elem.TNotOr elNotOr = new Log_elem.TNotOr();

            TestElement ( elXor, "A^B" );
            TestElement ( elNotAnd, "!(A&B)" );
            TestElement ( elNotOr, "!(A|B)" );

            while (!Console.KeyAvailable) ;
        }
    }
}
