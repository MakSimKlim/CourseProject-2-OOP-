﻿/*
  Программы к учебнику информатики для 11 класса углублённого уровня.
  Версия для C#.
  Авторы: К.Ю. Поляков, Е.А. Еремин
  E-mail: kpolyakov@mail.ru
  Сайт поддержки: http://kpolyakov.spb.ru

  Глава 7. Объектно-ориентированное программирование
  Проект № 1c. Домашние животные

  PETS_B.CS - добавлен класс TMammal - млекопитающие

*/
using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApplication1
{
    /*---------------------------------------------
      Класс TPet - домашнее животное
    ---------------------------------------------*/
    public abstract class TPet
    {
        private string FName;
        private int FAge;
        public TPet( string name0, int age0 ) { 
            FName = name0;
            FAge = age0;
        }
        public abstract void say();
        public void gettingOlder() {
          FAge ++;
        }
        public string name {
          get { return FName; }
        }
        public int age {
          get { return FAge; }
        }
    };
    /*---------------------------------------------
      Класс TMammal - млекопитающее, наследник TPet
    ---------------------------------------------*/
    public abstract class TMammal: TPet
    {
        public TMammal( string name0, int age0 ) : 
           base( name0, age0 ) { }
        public void run() {
          Console.WriteLine("{0} побежал...", this.name);
        }
    };
    /*---------------------------------------------
      Класс TCat - кошка, наследник TMammal
    ---------------------------------------------*/
    public class TCat : TMammal
    {
        public TCat( string name0, int age0 ) : 
           base( name0, age0 ) { }
        public override void say() {
          Console.WriteLine("{0}: Мяу!", this.name);
        }
    };
    /*---------------------------------------------
      Класс TDog - собака, наследник TMammal
    ---------------------------------------------*/
    public class TDog : TMammal
    {
        public TDog( string name0, int age0 ) : 
           base( name0, age0 ) { }
        public override void say() {
          Console.WriteLine("{0}: Гав!", this.name);
        }
    };
    /*--------------------------------------------
      Основная программа
    ---------------------------------------------*/
    class Program
    {
        static void Main(string[] args)
        {
            TPet[] pets = new TPet[2];
            pets[0] = new TCat("Мурзик", 3);
            pets[1] = new TDog("Шарик", 5);;
            foreach( TPet p in pets ) {
              p.say();
              if( p is TMammal )
                (p as TMammal).run();
            }
            Console.ReadKey();
        }
    }
}
