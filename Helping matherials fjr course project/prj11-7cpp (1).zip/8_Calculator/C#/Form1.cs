﻿/*
  Программы к учебнику информатики для 11 класса углублённого уровня.
  Визуальное программирование на C#.
  Авторы: К.Ю. Поляков, Е.А. Еремин
  E-mail: kpolyakov@mail.ru
  Сайт поддержки: http://kpolyakov.spb.ru

  Глава 7. Объектно-ориентированное программирование
  Проект № 8. Калькулятор
  
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class MainForm : Form
    {
        double x1, x2;
        string oper;
        bool nextNumber;
        public MainForm()
        {
            InitializeComponent();
        }

        private void Disp_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(Char.IsDigit(e.KeyChar) || e.KeyChar == (char)8))
            {
                switch (e.KeyChar)
                {
                    case '+': btnDiv_Click(btnPlus, null); break;
                    case '-': btnDiv_Click(btnMinus, null); break;
                    case '*': btnDiv_Click(btnMul, null); break;
                    case '/': btnDiv_Click(btnDiv, null); break;
                    case (char)13: btnCalc_Click(btnCalc, null); break;
                }
                e.Handled = true;
            }
            else
                if (nextNumber)
                {
                    Disp.Text = "";
                    nextNumber = false;
                }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            Disp.Text = "";
        }

        private void btnDiv_Click(object sender, EventArgs e)
        {
           x1 = double.Parse(Disp.Text);
           oper = (sender as Button).Text;
           nextNumber = true;
        }

        private void btnCalc_Click(object sender, EventArgs e)
        {
            double res = 0;
            if ( oper == "" ) return;
            x2 = double.Parse(Disp.Text);
            if ( oper == "+" ) res = x1 + x2;
            if ( oper == "-" ) res = x1 - x2;
            if ( oper == "*" ) res = x1 * x2;
            if ( oper == "/" ) res = x1 / x2;
            Disp.Text = res.ToString();
            nextNumber = true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
              if ( nextNumber ) 
              {
                Disp.Text = "";
                nextNumber = false;
              }
              Disp.Text = Disp.Text + (sender as Button).Text;
              Disp.SelectionStart = Disp.Text.Length;
        }
    }
}
