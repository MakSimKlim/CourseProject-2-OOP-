#include <iostream>
#include <iomanip>

using namespace std;

class TLogElement {
  private:
    bool FIn1, FIn2;
  protected:
    bool FRes;
    virtual void calc() = 0;              
    void setIn2(bool newIn2);
    bool getIn2() { return FIn2; }
  public:
    void setIn1(bool newIn1);
    bool getIn1() { return FIn1; }
    bool getRes() { return FRes; }              
  };

class TNot: public TLogElement {
  protected:   
    void calc();              
  };   

void TLogElement::setIn1(bool newIn1)
{
  FIn1 = newIn1;
  calc();     
}
void TLogElement::setIn2(bool newIn2)
{
  FIn2 = newIn2;
  calc();     
}

void TNot::calc()
{
  FRes = ! getIn1();    
}

class TLog2In: public TLogElement {
  public:
    TLogElement::setIn2;
    TLogElement::getIn2;
  };

class TAnd: public TLog2In {
  protected:
    void calc();                
  };      

void TAnd::calc()
{
  FRes = getIn1() &&  getIn2();    
}

class TOr: public TLog2In {
  protected:
    void calc();                
  };      

void TOr::calc()
{
  FRes = getIn1() ||  getIn2();    
}

main()
{
  TNot elNot;
  TAnd elAnd;
  int A, B;
  
  cout << " A  B  !(A&B)" << endl;
  cout << "----------------" << endl;
  for (A=0; A<=1; A++) {     
    elAnd.setIn1 ( A );
    for (B=0; B<=1; B++) {     
      elAnd.setIn2 ( B );
      elNot.setIn1 ( elAnd.getRes() );
      cout << " " << A << "  " << B
           << "    " << elNot.getRes() << endl;
      }
    }
       
  cin.get();
}
