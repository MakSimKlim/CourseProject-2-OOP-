 #include <iostream>
 using namespace std;
 
 class TRoad {
  public:     
   float Length;
   int Width;
   TRoad();
   TRoad(float length0, int width0 = 3);
   };

TRoad::TRoad()
{
  Length = 0;
  Width = 0;
}  
TRoad::TRoad(float length0, int width0)
{
  Length = length0;
  Width = width0;
} 
  
main()   
{
  TRoad road(60);

  cout << road.Length << " " << road.Width << endl;

  road.Length = 80;  
  road.Width = 4;

  cout << road.Length << " " << road.Width << endl;
  
  cin.get();         
}
