#include <iostream>
using namespace std;

class TCar {
  private:
    double Fv;        
  public:
    double getV() { return Fv; }     
  };              

main()
{
}
