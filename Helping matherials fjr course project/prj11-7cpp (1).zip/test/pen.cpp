#include <iostream>
using namespace std;

class TPen {
  private:
    string FColor;     
  public:
    string getColor() { return FColor; }            
    void setColor(string newColor);
  };      
  
void TPen::setColor(string newColor)
{
  if ( newColor.length() != 6 )
       FColor = "000000";  // ���� ������, �� ������ ���� 
  else FColor = newColor;       
}  

main()
{
   TPen pen;
   pen.setColor("111");
   cout << pen.getColor() << endl;
   pen.setColor("123456");
   cout << pen.getColor();
   cin.get();   
}
