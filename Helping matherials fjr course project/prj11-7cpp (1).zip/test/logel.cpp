#include <iostream>

using namespace std;

class TLogElement {
  private:
    bool FIn1, FIn2;
    bool FRes;
    void calc();
    void setIn2(bool newIn2);
    bool getIn2() { return FIn2; }
  public:
    void setIn1(bool newIn1);
    bool getIn1() { return FIn1; }
    bool getRes() { return FRes; }              
   };

void TLogElement::calc()
{
}

void TLogElement::setIn1(bool newIn1)
{
  FIn1 = newIn1;
  calc();     
}
void TLogElement::setIn2(bool newIn2)
{
  FIn2 = newIn2;
  calc();     
}

main()
{
  cin.get();      
}
