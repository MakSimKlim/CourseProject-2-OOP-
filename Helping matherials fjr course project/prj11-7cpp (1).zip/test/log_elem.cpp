#include "log_elem.h"
void TLogElement::setIn1(bool newIn1)
{
  FIn1 = newIn1;
  calc();     
}
void TNot::calc()
{
  FRes = ! getIn1();    
}
void TLog2In::setIn2(bool newIn2)
{
  FIn2 = newIn2;
  calc();     
}
void TAnd::calc()
{
  FRes = getIn1() &&  getIn2();    
}
void TOr::calc()
{
  FRes = getIn1() ||  getIn2();    
}

