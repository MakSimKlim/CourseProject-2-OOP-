class TLogElement {
  private:
    bool FIn1;
  protected:
    bool FRes;
    virtual void calc() = 0;              
  public:
    void setIn1(bool newIn1);
    bool getIn1() { return FIn1; }
    bool getRes() { return FRes; }              
  };
class TLog2In: public TLogElement {
  private:
    bool FIn2;
  public:
    void setIn2(bool newIn2);
    bool getIn2() { return FIn2; }
  };
class TNot: public TLogElement {
  protected:   
    void calc();              
  };   
class TAnd: public TLog2In {
  protected:
    void calc();                
  };      
class TOr: public TLog2In {
  protected:
    void calc();                
  };      

