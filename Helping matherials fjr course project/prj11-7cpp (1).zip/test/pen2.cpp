#include <iostream>
#include <iomanip>
#include <sstream>
using namespace std;

class TPen {
  private:
    int FColor;     
  public:
    string getColor();
    void setColor(string newColor);
  };      
  
string TPen::getColor()
{
  stringstream s;
  s << setfill('0') << setw(6) 
    << hex << FColor;   
  return s.str();       
}  

void TPen::setColor(string newColor)
{
  stringstream s;
  if ( newColor.length() != 6 )      
    FColor = 0;  // ���� ������, �� ������ ���� 
  else {
    s << newColor;
    s >> hex >> FColor;
    }
}  

main()
{
   TPen pen;
   pen.setColor("111");
   cout << pen.getColor() << endl;
   pen.setColor("123456");
   cout << pen.getColor();
   cin.get();   
}
