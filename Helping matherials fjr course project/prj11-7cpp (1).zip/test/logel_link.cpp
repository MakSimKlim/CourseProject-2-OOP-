#include <iostream>
#include <iomanip>
#include "log_elem_link.h"

using namespace std;

main()
{
  TNot elNot;
  TAnd elAnd;
  int A, B;
  
  cout << " A  B  !(A&B)" << endl;
  cout << "-------------" << endl;
  elAnd.Link(&elNot);
  for (A=0; A<=1; A++) {     
    elAnd.setIn1 ( A );
    for (B=0; B<=1; B++) {     
      elAnd.setIn2 ( B );
//      elNot.setIn1 ( elAnd.getRes() );
      cout << " " << A << "  " << B
           << "    " << elNot.getRes() << endl;
      }
    }
       
  cin.get();
}
