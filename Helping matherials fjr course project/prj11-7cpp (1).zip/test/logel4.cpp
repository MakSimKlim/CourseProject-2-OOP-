#include <iostream>
#include <iomanip>

using namespace std;

class TLogElement {
  private:
    bool FIn1, FIn2;
  protected:
    bool FRes;
    virtual void calc() = 0;              
    void setIn2(bool newIn2);
    bool getIn2() { return FIn2; }
  public:
    void setIn1(bool newIn1);
    bool getIn1() { return FIn1; }
    bool getRes() { return FRes; }              
  };

class TNot: public TLogElement {
  protected:   
    void calc();              
  };   

void TLogElement::setIn1(bool newIn1)
{
  FIn1 = newIn1;
  calc();     
}
void TLogElement::setIn2(bool newIn2)
{
  FIn2 = newIn2;
  calc();     
}

void TNot::calc()
{
  FRes = ! getIn1();    
}

class TLog2In: public TLogElement {
  public:
    TLogElement::setIn2;
    TLogElement::getIn2;
  };

class TAnd: public TLog2In {
  protected:
    void calc();                
  };      

void TAnd::calc()
{
  FRes = getIn1() &&  getIn2();    
}

class TOr: public TLog2In {
  protected:
    void calc();                
  };      

void TOr::calc()
{
  FRes = getIn1() ||  getIn2();    
}

main()
{
  TAnd elAnd;
  TOr elOr;
  int i1, i2;
  
  cout << "And:" << endl << "i1 i2 Res" << endl << "----------------" << endl;
  for (i1=0; i1<=1; i1++) {     
    for (i2=0; i2<=1; i2++) {     
      elAnd.setIn1 ( i1 );
      elAnd.setIn2 ( i2 );
      cout << setw(2) << elAnd.getIn1() << setw(3) << elAnd.getIn2() 
           << setw(3) << elAnd.getRes() << endl;
      }
    }

  cout << endl << "Or:" << endl << "i1 i2 Res" << endl << "----------------" << endl;
  for (i1=0; i1<=1; i1++) {     
    for (i2=0; i2<=1; i2++) {     
      elOr.setIn1 ( i1 );
      elOr.setIn2 ( i2 );
      cout << setw(2) << elOr.getIn1() << setw(3) << elOr.getIn2() 
           << setw(3) << elOr.getRes() << endl;
      }
    }
    
  cin.get();
}
