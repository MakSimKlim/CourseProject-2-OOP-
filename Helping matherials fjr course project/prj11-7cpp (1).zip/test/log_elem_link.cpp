#include <cstdlib>
#include "log_elem_link.h"

TLogElement::TLogElement()
{
  FNextEl = NULL;                           
}
void TLogElement::setIn1(bool newIn1)
{
  FIn1 = newIn1;
  calc();     
  if ( FNextEl )
    switch ( FNextIn ) {
      case 1: FNextEl->setIn1 ( getRes() );
      case 2: FNextEl->setIn2 ( getRes() );
      }
}
void TLogElement::setIn2(bool newIn2)
{
  FIn2 = newIn2;
  calc();     
  if ( FNextEl )
    switch ( FNextIn ) {
      case 1: FNextEl->setIn1 ( getRes() );
      case 2: FNextEl->setIn2 ( getRes() );
      }
}
void TLogElement::Link(TLogElement *nextElement, int nextIn)
{
  FNextEl = nextElement;
  FNextIn = nextIn;    
}
void TNot::calc()
{
  FRes = ! getIn1();    
}
void TAnd::calc()
{
  FRes = getIn1() &&  getIn2();    
}
void TOr::calc()
{
  FRes = getIn1() ||  getIn2();    
}
