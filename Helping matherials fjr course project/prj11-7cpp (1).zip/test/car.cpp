#include <iostream>
#include <conio.h>

using namespace std;
 
class TRoad {
 public:     
  float Length;
  int Width;
  TRoad();
  TRoad(float length0, int width0 = 3);
  };

TRoad::TRoad()
{
  Length = 0;
  Width = 0;
}  
TRoad::TRoad(float length0, int width0)
{
  if ( length0 > 0 )
       Length = length0;
  else Length = 1;
  if ( width0 > 0 )
       Width = width0;
  else Width = 1;
} 
   
class TCar {
 public:     
  float X, V;
  int P; 
  TRoad *Road;
  void move();
  TCar ();
  TCar ( TRoad *road0, int p0, float v0 );
  };  

TCar::TCar()
{
  Road = NULL; P = 0; V = 0; X = 0;            
}

TCar::TCar ( TRoad *road0, int p0, float v0 )
{
  Road = road0; P = p0; V = v0; X = 0;            
}
void TCar:: move()
{
  X = X + V;                                   
  if ( X > Road->Length ) X = 0;               
}
 
main()   
{
  TRoad road(60);
  const int N = 3;
  TCar cars[N] = { TCar(&road, 1, 2.),
                   TCar(&road, 2, 4.),
                   TCar(&road, 3, 6.) } ;
  int i;                   
  for (i=0; i<N; i++) {
     cars[i].Road = &road; 
     cars[i].P = i + 1;   
     cars[i].V = 2.0*(i + 1);   
     }     

  for (i=0; i<N; i++) 
     cout << "P = " << cars[i].P 
          << "  V = " <<  cars[i].V << endl;   
          
  do {
    for (i=0; i<N; i++) {
      cars[i].move();        
      }          
    cout << cars[i].X;  
    }
  while ( !kbhit() );
    
  cin.get();         
}
