#include <iostream>
#include <iomanip>

using namespace std;

class TLogElement {
  private:
    bool FIn1, FIn2;
  protected:
    bool FRes;
    virtual void calc() = 0;              
    void setIn2(bool newIn2);
    bool getIn2() { return FIn2; }
  public:
    void setIn1(bool newIn1);
    bool getIn1() { return FIn1; }
    bool getRes() { return FRes; }              
  };

class TNot: public TLogElement {
  protected:   
    void calc();              
  };   

void TLogElement::setIn1(bool newIn1)
{
  FIn1 = newIn1;
  calc();     
}
void TLogElement::setIn2(bool newIn2)
{
  FIn2 = newIn2;
  calc();     
}

void TNot::calc()
{
  FRes = ! getIn1();    
}

main()
{
  TNot elNot;
  int i1;

  cout << endl << "Not:" << endl << "i1 Res" << endl << "-------------" << endl;
  for (i1=0; i1<=1; i1++) {     
    elNot.setIn1 ( i1 );
    cout << setw(2) << elNot.getIn1() << setw(3) << elNot.getRes() << endl;
    }
  cin.get();
}
