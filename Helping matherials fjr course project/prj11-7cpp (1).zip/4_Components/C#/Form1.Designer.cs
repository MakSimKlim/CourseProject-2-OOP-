﻿/*
  Программы к учебнику информатики для 11 класса углублённого уровня.
  Визуальное программирование на C#.
  Авторы: К.Ю. Поляков, Е.А. Еремин
  E-mail: kpolyakov@mail.ru
  Сайт поддержки: http://kpolyakov.spb.ru

  Глава 7. Объектно-ориентированное программирование
  Проект № 4. Использование компонентов
  
*/
namespace Components
{
    partial class MainForm
    {
        /// <summary>
        /// Требуется переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Обязательный метод для поддержки конструктора - не изменяйте
        /// содержимое данного метода при помощи редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.SizeCB = new System.Windows.Forms.CheckBox();
            this.OpenBtn = new System.Windows.Forms.Button();
            this.Img = new System.Windows.Forms.PictureBox();
            this.OpenDlg = new System.Windows.Forms.OpenFileDialog();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Img)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.OpenBtn);
            this.panel1.Controls.Add(this.SizeCB);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(314, 40);
            this.panel1.TabIndex = 0;
            // 
            // SizeCB
            // 
            this.SizeCB.AutoSize = true;
            this.SizeCB.Location = new System.Drawing.Point(128, 12);
            this.SizeCB.Name = "SizeCB";
            this.SizeCB.Size = new System.Drawing.Size(122, 17);
            this.SizeCB.TabIndex = 0;
            this.SizeCB.Text = "По размерам окна";
            this.SizeCB.UseVisualStyleBackColor = true;
            this.SizeCB.CheckedChanged += new System.EventHandler(this.SizeCB_CheckedChanged);
            // 
            // OpenBtn
            // 
            this.OpenBtn.Location = new System.Drawing.Point(11, 9);
            this.OpenBtn.Name = "OpenBtn";
            this.OpenBtn.Size = new System.Drawing.Size(100, 23);
            this.OpenBtn.TabIndex = 1;
            this.OpenBtn.Text = "Открыть файл";
            this.OpenBtn.UseVisualStyleBackColor = true;
            this.OpenBtn.Click += new System.EventHandler(this.OpenBtn_Click);
            // 
            // Img
            // 
            this.Img.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Img.Location = new System.Drawing.Point(0, 40);
            this.Img.Name = "Img";
            this.Img.Size = new System.Drawing.Size(314, 127);
            this.Img.TabIndex = 1;
            this.Img.TabStop = false;
            // 
            // OpenDlg
            // 
            this.OpenDlg.Filter = "\"Файлы с рисунками|*.jpg;*.jpeg;*.gif;*.bmp\"";
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(314, 167);
            this.Controls.Add(this.Img);
            this.Controls.Add(this.panel1);
            this.Name = "MainForm";
            this.Text = "Просмотр рисунков";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Img)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button OpenBtn;
        private System.Windows.Forms.CheckBox SizeCB;
        private System.Windows.Forms.PictureBox Img;
        private System.Windows.Forms.OpenFileDialog OpenDlg;
    }
}

