﻿/*
  Программы к учебнику информатики для 11 класса углублённого уровня.
  Визуальное программирование на C#.
  Авторы: К.Ю. Поляков, Е.А. Еремин
  E-mail: kpolyakov@mail.ru
  Сайт поддержки: http://kpolyakov.spb.ru

  Глава 7. Объектно-ориентированное программирование
  Проект № 4. Использование компонентов
  
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Components
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void OpenBtn_Click(object sender, EventArgs e)
        {
            OpenDlg.Filter = "Файлы с рисунками|*.jpg;*.jpeg;*.gif;*.bmp";
            if (OpenDlg.ShowDialog() == DialogResult.OK)
            {
                Img.Image = new Bitmap(OpenDlg.FileName);
            } 

        }

        private void SizeCB_CheckedChanged(object sender, EventArgs e)
        {
            if (SizeCB.Checked) 
                 Img.SizeMode = PictureBoxSizeMode.Zoom;
            else Img.SizeMode = PictureBoxSizeMode.Normal;
        }
    }
}
