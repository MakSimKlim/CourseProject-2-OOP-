﻿/*
  Программы к учебнику информатики для 11 класса углублённого уровня.
  Версия для C#.
  Авторы: К.Ю. Поляков, Е.А. Еремин
  E-mail: kpolyakov@mail.ru
  Сайт поддержки: http://kpolyakov.spb.ru

  Глава 7. Объектно-ориентированное программирование
  Проект № 1. Движение на дороге

  project1 - начальный вариант

*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    /*---------------------------------------------
      Класс TRoad - модель дороги
    ---------------------------------------------*/
    class TRoad
    {
        public float Length;
        public int Width;
        public TRoad() { Length = 0; Width = 0; }
        public TRoad(float length0, int width0 = 3)
        {
            if (length0 > 0)
                Length = length0;
            else Length = 1;
            if (width0 > 0)
                Width = width0;
            else Width = 1;
        }
    };
    /*--------------------------------------------
      Класс TCar - модель автомашины
    ---------------------------------------------*/
    class TCar
    {
        public double X, V;
        public int P;
        public TRoad Road;
        public void move()
        {
            X = X + V;
            if (X > Road.Length) X = 0;
        }
        public TCar() { Road = null; P = 0; V = 0; X = 0; }
        public TCar(TRoad road0, int p0, float v0)
        {
            Road = road0; P = p0; V = v0; X = 0;
        }
    };
    /*--------------------------------------------
      Основная программа
    ---------------------------------------------*/
    class Program
    {
        static void Main(string[] args)
        {
        TRoad road = new TRoad(60);
        const int N = 3;
        TCar[] cars = new TCar[3];
        for (int i=0; i<N; i++) 
          {
          cars[i] = new TCar();
          cars[i].Road = road; 
          cars[i].P = i + 1;   
          cars[i].V = 2.0*(i + 1);   
          }         
        
        while(!Console.KeyAvailable)
          {
          for (int i=0; i<N; i++) 
            cars[i].move();        
          }
        }
    }
}
