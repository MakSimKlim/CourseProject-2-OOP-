﻿/*
  Программы к учебнику информатики для 11 класса углублённого уровня.
  Версия для C#.
  Авторы: К.Ю. Поляков, Е.А. Еремин
  E-mail: kpolyakov@mail.ru
  Сайт поддержки: http://kpolyakov.spb.ru

  Глава 7. Объектно-ориентированное программирование
  Проект № 1. Движение на дороге

  project1_4 - модификация 4
     + добавлен светофор, который переключается

*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    /*---------------------------------------------
      Класс TRoad - модель дороги
    ---------------------------------------------*/
    class TRoad
    {
        public float Length;
        public int Width;
        public TRoad() { Length = 0; Width = 0; }
        public TRoad(float length0, int width0 = 3)
        {
            if (length0 > 0)
                Length = length0;
            else Length = 1;
            if (width0 > 0)
                Width = width0;
            else Width = 1;
        }
    };
    /*--------------------------------------------
      Класс TCar - модель автомашины
    ---------------------------------------------*/
    class TCar
    {
        public double X, V;
        public int P;
        public TRoad Road;
        public void show()     // + метод для оказа машины на экране   
        {
            Console.SetCursorPosition((int)(X + 1), P);
            Console.Write("->");
        }
        public void hide()    // + метод для скрытия машины с экрана  
        {
            Console.SetCursorPosition((int)(X + 1), P);
            Console.Write("  ");
        }
        public void move()
        {
            hide();
            X = X + V;
            if (X > Road.Length) X = 0;
            show();
        }
        public TCar() { Road = null; P = 0; V = 0; X = 0; }
        public TCar(TRoad road0, int p0, float v0)
        {
            Road = road0; P = p0; V = v0; X = 0;
        }
    };
    /*---------------------------------------------
      Класс TLight - модель светофора
    ---------------------------------------------*/
    class TLight
    {
        ConsoleColor color;
        int X;
        int stateCounter;
        public TLight(int X0)
        {
            X = X0;
            stateCounter = 0;
            color = ConsoleColor.Red;
        }
        public void timeStep()
        {
            stateCounter++;
            switch (stateCounter)
            {
                case 50: color = ConsoleColor.Yellow; break;
                case 60: color = ConsoleColor.Green; break;
                case 110: color = ConsoleColor.Yellow; break;
                case 120:
                    color = ConsoleColor.Red;
                    stateCounter = 0;
                    break;
            }
            show();
        }
        public void show()
        {
            Console.SetCursorPosition((int)X, 0);
            Console.BackgroundColor = color;
            Console.Write(" ");
            Console.BackgroundColor = ConsoleColor.Black;
        }
    };
    /*--------------------------------------------
      Основная программа
    ---------------------------------------------*/
    class Program
    {
        static void Main(string[] args)
        {
            TRoad road = new TRoad(60);
            TLight Light = new TLight(30);
            const int N = 3;
            TCar[] cars = new TCar[3];
            for (int i = 0; i < N; i++)
            {
                cars[i] = new TCar();
                cars[i].Road = road;
                cars[i].P = i + 1;
                cars[i].V = 2.0 * (i + 1);
            }

            Light.show();

            while (!Console.KeyAvailable)
            {
                for (int i = 0; i < N; i++)
                {
                    cars[i].move();
                }
                Light.timeStep();
                System.Threading.Thread.Sleep(100);
            }
        }
    }
}
