﻿/*
  Программы к учебнику информатики для 11 класса углублённого уровня.
  Версия для C#.
  Авторы: К.Ю. Поляков, Е.А. Еремин
  E-mail: kpolyakov@mail.ru
  Сайт поддержки: http://kpolyakov.spb.ru

  Глава 7. Объектно-ориентированное программирование
  Проект № 1b. Ряд лампочек - управление состоянием

  LAMPROW_A.CS - начальный вариант

*/
using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApplication1
{
    /*---------------------------------------------
      Класс TLampRow - модель ряда лампочек
    ---------------------------------------------*/
    class TLampRow
    {
        private string state;        
        public TLampRow() { state = "00000000"; }
        public string getState() { return state; }     
        public void setState( string newState ) { 
            if( newState.Length == 8 )
                state = newState; 
            else state = "00000000";
        } 
        public void show() {
            char[] notation = { '-', '*' };	
            for( int i = 0; i < state.Length; i++ ) {  
                int pos = state[i] - (int)'0';
                Console.Write( notation[pos] );
            } 
            Console.WriteLine();
        }
    };
    /*--------------------------------------------
      Основная программа
    ---------------------------------------------*/
    class Program
    {
        static void Main(string[] args)
        {
            TLampRow lamps = new TLampRow();
            lamps.show();
            lamps.setState("10101010");
            Console.WriteLine( lamps.getState() );
            lamps.show();
            Console.ReadKey();
        }
    }
}
