﻿/*
  Программы к учебнику информатики для 11 класса углублённого уровня.
  Версия для C#.
  Авторы: К.Ю. Поляков, Е.А. Еремин
  E-mail: kpolyakov@mail.ru
  Сайт поддержки: http://kpolyakov.spb.ru

  Глава 7. Объектно-ориентированное программирование
  Проект № 1b. Ряд лампочек - управление состоянием

  LAMPROW_C.CS - модификация 2
     + лампочки могут гореть одним из двух цветов:
       1 - красный (* при выводе)
       2 - зелёный (o при выводе)

*/
using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApplication1
{
    /*---------------------------------------------
      Класс TLampRow - модель ряда лампочек
    ---------------------------------------------*/
    class TLampRow
    {
        private string state;        
        public TLampRow( int count ) {
            state = new string('0', count); 
        }
        public string getState() { return state; }     
        public void setState( string newState ) { 
            if( newState.Length == state.Length )
                state = newState;
            else state = new string('0', state.Length);
        } 
        public void show() {
            char[] notation = { '-', '*', 'o' };	
            for( int i = 0; i < state.Length; i++ ) {  
                int pos = state[i] - (int)'0';
                Console.Write( notation[pos] );
            } 
            Console.WriteLine();
        }
    };
    /*--------------------------------------------
      Основная программа
    ---------------------------------------------*/
    class Program
    {
        static void Main(string[] args)
        {
            TLampRow lamps = new TLampRow( 6 );
            lamps.show();
            lamps.setState("102102");
            Console.WriteLine( lamps.getState() );
            lamps.show();
            lamps.setState("10201010");
            Console.WriteLine(lamps.getState());
            lamps.show();
            Console.ReadKey();
        }
    }
}
