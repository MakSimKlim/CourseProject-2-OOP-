﻿/*
  Программы к учебнику информатики для 11 класса углублённого уровня.
  Версия для C#.
  Авторы: К.Ю. Поляков, Е.А. Еремин
  E-mail: kpolyakov@mail.ru
  Сайт поддержки: http://kpolyakov.spb.ru

  Глава 7. Объектно-ориентированное программирование
  Проект № 1b. Ряд лампочек - управление состоянием

  LAMPROW_D.CS - модификация 3
     + код хранится как целое число, интерфейс не меняется

*/
using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApplication1
{
    /*---------------------------------------------
      Класс TLampRow - модель ряда лампочек
    ---------------------------------------------*/
    class TLampRow
    {
        private int count;
        private int state;
        public TLampRow(int count0)
        {
            count = count0;
            state = 0; 
        }
        public string getState() {
            return intToTrinary(state, count); 
        }
        private string intToTrinary(int n, int count )
        {
            const int BASE = 3;
            string Result = "";
            for (int i = count-1; i >= 0; i--) {
                Result = (char) (n % BASE + (int)'0') + Result;
                n /= BASE;
            }
            return Result;
        }
        private int trinaryToInt(string s)
        {
            int Result = 0;
            for (int i = 0; i < s.Length; i++)
                Result = 3 * Result + s[i] - '0';
            return Result;
        }
        public void setState(string newState)
        { 
            if( newState.Length == count )
                state = trinaryToInt( newState );
            else state = 0;
        } 
        public void show() {
            char[] notation = { '-', '*', 'o' };
            string s = intToTrinary(state, count);
            for( int i = 0; i < count; i++ ) {  
                int pos = s[i] - '0';
                Console.Write( notation[pos] );
            } 
            Console.WriteLine();
        }
    };
    /*--------------------------------------------
      Основная программа
    ---------------------------------------------*/
    class Program
    {
        static void Main(string[] args)
        {
            TLampRow lamps = new TLampRow( 6 );
            lamps.show();
            lamps.setState("102102");
            Console.WriteLine( lamps.getState() );
            lamps.show();
            lamps.setState("10201010");
            Console.WriteLine(lamps.getState());
            lamps.show(); 
            Console.ReadKey();
        }
    }
}
