﻿/*
  Программы к учебнику информатики для 11 класса углублённого уровня.
  Визуальное программирование на C#.
  Авторы: К.Ю. Поляков, Е.А. Еремин
  E-mail: kpolyakov@mail.ru
  Сайт поддержки: http://kpolyakov.spb.ru

  Глава 7. Объектно-ориентированное программирование
  Проект № 5a. Компоненты для ввода данных
  
  ROOM_A - вычисление площади комнаты 
  
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Globalization;

namespace Room
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            // rEdit_TextChanged(rEdit, e);
            LEdit_TextChanged(null, null);
        }

        private void LEdit_TextChanged(object sender, EventArgs e)
        {
            float L, W, S;
            try
            {
                L = float.Parse(LEdit.Text);
                W = float.Parse(WEdit.Text);
                if (L < 0 || W < 0)
                    throw new InvalidCastException();
                S = L * W;
                SLabel.Text = "Площадь " + S.ToString("0.00") + " кв. м";
            }
            catch
            {
                SLabel.Text = "Площадь ? кв. м";
            }
        }

        private void LEdit_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ( ! ( Char.IsDigit(e.KeyChar) || e.KeyChar == (char) 8
                     || e.KeyChar == ',' || e.KeyChar == '-') )
                e.Handled = true;
        }
    }
}
