﻿/*
  Программы к учебнику информатики для 11 класса углублённого уровня.
  Визуальное программирование на C#.
  Авторы: К.Ю. Поляков, Е.А. Еремин
  E-mail: kpolyakov@mail.ru
  Сайт поддержки: http://kpolyakov.spb.ru

  Глава 7. Объектно-ориентированное программирование
  Проект № 5a. Компоненты для ввода данных
  
  ROOM_A - вычисление площади комнаты 
  
*/
namespace Room
{
    partial class MainForm
    {
        /// <summary>
        /// Требуется переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Обязательный метод для поддержки конструктора - не изменяйте
        /// содержимое данного метода при помощи редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.LEdit = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.WEdit = new System.Windows.Forms.TextBox();
            this.SLabel = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.REdit = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.HEdit = new System.Windows.Forms.TextBox();
            this.RLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // LEdit
            // 
            this.LEdit.Location = new System.Drawing.Point(82, 11);
            this.LEdit.Margin = new System.Windows.Forms.Padding(4);
            this.LEdit.Name = "LEdit";
            this.LEdit.Size = new System.Drawing.Size(54, 23);
            this.LEdit.TabIndex = 0;
            this.LEdit.Text = "5";
            this.LEdit.TextChanged += new System.EventHandler(this.LEdit_TextChanged);
            this.LEdit.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.LEdit_KeyPress);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 14);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(63, 17);
            this.label1.TabIndex = 1;
            this.label1.Text = "Длина =";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(9, 40);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(71, 17);
            this.label2.TabIndex = 2;
            this.label2.Text = "Ширина =";
            // 
            // WEdit
            // 
            this.WEdit.Location = new System.Drawing.Point(82, 37);
            this.WEdit.Margin = new System.Windows.Forms.Padding(4);
            this.WEdit.Name = "WEdit";
            this.WEdit.Size = new System.Drawing.Size(54, 23);
            this.WEdit.TabIndex = 4;
            this.WEdit.Text = "3";
            this.WEdit.TextChanged += new System.EventHandler(this.LEdit_TextChanged);
            this.WEdit.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.LEdit_KeyPress);
            // 
            // SLabel
            // 
            this.SLabel.AutoSize = true;
            this.SLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.SLabel.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.SLabel.Location = new System.Drawing.Point(9, 119);
            this.SLabel.Name = "SLabel";
            this.SLabel.Size = new System.Drawing.Size(162, 16);
            this.SLabel.TabIndex = 6;
            this.SLabel.Text = "Площадь стен ? кв. м";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(143, 14);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(17, 17);
            this.label3.TabIndex = 7;
            this.label3.Text = "м";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(143, 40);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(17, 17);
            this.label4.TabIndex = 8;
            this.label4.Text = "м";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(143, 92);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(39, 17);
            this.label5.TabIndex = 14;
            this.label5.Text = "кв. м";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(143, 66);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(17, 17);
            this.label6.TabIndex = 13;
            this.label6.Text = "м";
            // 
            // REdit
            // 
            this.REdit.Location = new System.Drawing.Point(82, 89);
            this.REdit.Margin = new System.Windows.Forms.Padding(4);
            this.REdit.Name = "REdit";
            this.REdit.Size = new System.Drawing.Size(54, 23);
            this.REdit.TabIndex = 12;
            this.REdit.Text = "8";
            this.REdit.TextChanged += new System.EventHandler(this.LEdit_TextChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(9, 92);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(68, 17);
            this.label7.TabIndex = 11;
            this.label7.Text = "В рулоне";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(9, 66);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(69, 17);
            this.label8.TabIndex = 10;
            this.label8.Text = "Высота =";
            // 
            // HEdit
            // 
            this.HEdit.Location = new System.Drawing.Point(82, 63);
            this.HEdit.Margin = new System.Windows.Forms.Padding(4);
            this.HEdit.Name = "HEdit";
            this.HEdit.Size = new System.Drawing.Size(54, 23);
            this.HEdit.TabIndex = 9;
            this.HEdit.Text = "3,6";
            this.HEdit.TextChanged += new System.EventHandler(this.LEdit_TextChanged);
            // 
            // RLabel
            // 
            this.RLabel.AutoSize = true;
            this.RLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.RLabel.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.RLabel.Location = new System.Drawing.Point(9, 140);
            this.RLabel.Name = "RLabel";
            this.RLabel.Size = new System.Drawing.Size(154, 16);
            this.RLabel.TabIndex = 15;
            this.RLabel.Text = "Нужно ? рулона(ов)";
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(225, 166);
            this.Controls.Add(this.RLabel);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.REdit);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.HEdit);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.SLabel);
            this.Controls.Add(this.WEdit);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.LEdit);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "MainForm";
            this.Text = "Площадь комнаты";
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox LEdit;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox WEdit;
        private System.Windows.Forms.Label SLabel;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox REdit;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox HEdit;
        private System.Windows.Forms.Label RLabel;
    }
}

